// src/plugins/iframe/locale/zh-cn.ts
export default {
  cardLink: {
    title: '嵌入链接',
    placeholder: '将三方页面链接粘贴到此处',
    inputPlaceholder: 'https://example.com',
    button: '确认',
  },
};